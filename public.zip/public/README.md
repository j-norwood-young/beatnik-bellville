Files here will be copied as-is to public directory.
